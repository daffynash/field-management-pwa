// TaskTypes.js
export const TASK_TYPES = {
  CUT: "Κόψιμο",
  TURN: "Γύρισμα",
  BIND: "Δέσιμο"
};
